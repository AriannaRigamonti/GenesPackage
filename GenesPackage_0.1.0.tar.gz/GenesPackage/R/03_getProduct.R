#' Get the gene product
#'
#' This function retrieves the product of a gene.
#'
#' @param object A Gene object.
#' @return The gene product.
#' @export
#' @aliases getProduct getProduct,Gene-method
#' @examples
#' gene <- createGene(1L, "SYMBOL", "Gene Name", "Description", "chr1", 1, 1000, "+", list())
#' getProduct(gene)
setGeneric("getProduct", function(object) standardGeneric("getProduct"))

#' @rdname getProduct
#' @export
setMethod("getProduct", "Gene", function(object) object@product)

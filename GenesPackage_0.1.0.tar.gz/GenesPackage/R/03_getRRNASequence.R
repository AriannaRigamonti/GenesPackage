#' Get the rRNA sequence
#'
#' This function retrieves the sequence of a rRNA gene.
#'
#' @param object A rRNAGene object.
#' @return The rRNA sequence.
#' @export
#' @aliases getRRNASequence getRRNASequence,rRNAGene-method
#' @examples
#' rrna_gene <- createRRNAGene(
#'   7L, "SYMBOL_R", "rRNA Name",
#'   "rRNA Description", "chr1", 1, 1000, "+", list(),
#'   "rrna1", "RRNA_SEQ"
#' )
#' getRRNASequence(rrna_gene)
setGeneric("getRRNASequence", function(object) standardGeneric("getRRNASequence"))

#' @rdname getRRNASequence
#' @export
setMethod("getRRNASequence", "rRNAGene", function(object) object@rRNASequence)

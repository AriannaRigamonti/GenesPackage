#' Set the snoRNA sequence
#' @name setSnoRNASequence<-
#' @title Set the snoRNA sequence
#' @param object A snoRNAGene object.
#' @param value The new snoRNA sequence.
#' @return The updated snoRNAGene object.
#' @export
#' @aliases setSnoRNASequence setSnoRNASequence<-,snoRNAGene-method
#' @examples
#' snorna_gene <- createSnoRNAGene(
#'   5L, "SYMBOL_SNO", "snoRNA Name",
#'   "snoRNA Description", "chr1", 1, 1000, "+",
#'   list(), "snorna1", "SNORNA_SEQ"
#' )
#' setSnoRNASequence(snorna_gene) <- "NEW_SNORNA_SEQ"
#' getSnoRNASequence(snorna_gene)
setGeneric("setSnoRNASequence<-", function(object, value) standardGeneric("setSnoRNASequence<-"))
setMethod("setSnoRNASequence<-", "snoRNAGene", function(object, value) {
  object@snoRNASequence <- value
  object
})

#' rRNAGene class
#'
#' A class representing a rRNA gene.
#'
#' @slot rRNAID character. The rRNA ID.
#' @slot rRNASequence character. The rRNA sequence.
#' @exportClass rRNAGene
#' @importFrom GenomicRanges GRanges seqnames start end strand
#' @importFrom IRanges IRanges
#' @importFrom methods new
#' @examples
#' gr <- GenomicRanges::GRanges(
#'   seqnames = "chr1",
#'   ranges = IRanges::IRanges(start = 1, end = 1000)
#' )
#' rrna_gene <- new("rRNAGene",
#'   ID = 7L, symbol = "SYMBOL_R",
#'   name = "rRNA Name", description = "rRNA Description",
#'   structure = gr, product = list(), rRNAID = "rrna1",
#'   rRNASequence = "RRNA_SEQ"
#' )
setClass("rRNAGene",
  contains = "Gene",
  slots = list(
    rRNAID = "character",
    rRNASequence = "character"
  )
)

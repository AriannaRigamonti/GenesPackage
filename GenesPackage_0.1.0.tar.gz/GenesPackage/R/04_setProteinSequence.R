#' Set the protein sequence
#'
#' This method sets the protein sequence of a ProteinCodingGene object.
#'
#' @param object A ProteinCodingGene object.
#' @param value The new protein sequence.
#' @return The updated ProteinCodingGene object.
#' @title Set the protein sequence
#' @name setProteinSequence
#' @aliases setProteinSequence<- setProteinSequence<-,ProteinCodingGene-method
#' @rdname setProteinSequence
#' @export
#' @examples
#' protein_gene <- createProteinCodingGene(
#'   1L, "SYMBOL", "Gene Name",
#'   "Description", "chr1", 1, 1000,
#'   "+", list(), "protein1", "SEQUENCE"
#' )
#' setProteinSequence(protein_gene) <- "NEW_SEQUENCE"
#' getProteinSequence(protein_gene)
setGeneric("setProteinSequence<-", function(object, value) {
  standardGeneric("setProteinSequence<-")
})

#' @rdname setProteinSequence
#' @export
setMethod("setProteinSequence<-", "ProteinCodingGene", function(object, value) {
  object@proteinSequence <- value
  object
})

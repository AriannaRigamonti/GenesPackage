#' Get the gene name
#'
#' This function retrieves the name of a gene.
#'
#' @param object A Gene object.
#' @return The gene name.
#' @export
#' @aliases getName getName,Gene-method
#' @examples
#' gene <- createGene(1L, "SYMBOL", "Gene Name", "Description", "chr1", 1, 1000, "+", list())
#' getName(gene)
setGeneric("getName", function(object) standardGeneric("getName"))

#' @rdname getName
#' @export
setMethod("getName", "Gene", function(object) object@name)

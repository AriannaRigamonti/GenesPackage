#' Set the snoRNA ID
#' @name setSnoRNAID<-
#' @title Set the snoRNA ID
#' @param object A snoRNAGene object.
#' @param value The new snoRNA ID.
#' @return The updated snoRNAGene object.
#' @export
#' @aliases setSnoRNAID setSnoRNAID<-,snoRNAGene-method
#' @examples
#' snorna_gene <- createSnoRNAGene(
#'   5L, "SYMBOL_SNO", "snoRNA Name",
#'   "snoRNA Description", "chr1", 1, 1000, "+",
#'   list(), "snorna1", "SNORNA_SEQ"
#' )
#' setSnoRNAID(snorna_gene) <- "new_snorna1"
#' getSnoRNAID(snorna_gene)
setGeneric("setSnoRNAID<-", function(object, value) standardGeneric("setSnoRNAID<-"))
setMethod("setSnoRNAID<-", "snoRNAGene", function(object, value) {
  object@snoRNAID <- value
  object
})

#' siRNAGene class
#'
#' A class representing a siRNA gene.
#'
#' @slot siRNAID character. The siRNA ID.
#' @slot siRNASequence character. The siRNA sequence.
#' @exportClass siRNAGene
#' @importFrom GenomicRanges GRanges seqnames start end strand
#' @importFrom IRanges IRanges
#' @importFrom methods new
#' @examples
#' gr <- GenomicRanges::GRanges(
#'   seqnames = "chr1",
#'   ranges = IRanges::IRanges(start = 1, end = 1000)
#' )
#' sirna_gene <- new("siRNAGene",
#'   ID = 4L, symbol = "SYMBOL_SI",
#'   name = "siRNA Name", description = "siRNA Description",
#'   structure = gr, product = list(),
#'   siRNAID = "sirna1", siRNASequence = "SIRNA_SEQ"
#' )
setClass("siRNAGene",
  contains = "Gene",
  slots = list(
    siRNAID = "character",
    siRNASequence = "character"
  )
)

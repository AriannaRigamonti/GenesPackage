#' Create a piRNAGene object
#'
#' @param ID integer The gene ID (e.g., Ensembl ID or NCBI gene ID).
#' @param symbol character. The gene symbol.
#' @param name character. The gene name.
#' @param description character. The gene description.
#' @param chr character. The chromosome location.
#' @param start numeric. The start position of the gene.
#' @param end numeric. The end position of the gene.
#' @param strand character. The strand of the gene.
#' @param product list. The gene product.
#' @param piRNAID character. The piRNA ID.
#' @param piRNASequence character. The piRNA sequence.
#' @return A piRNAGene object.
#' @export
#' @examples
#' pirna_gene <- createPiRNAGene(
#'   8L, "SYMBOL_PI", "piRNA Name", "piRNA Description",
#'   "chr1", 1, 1000, "+", list(), "pirna1", "PIRNA_SEQ"
#' )
#' pirna_gene
createPiRNAGene <- function(ID, symbol, name, description, chr, start, end, strand, product, piRNAID, piRNASequence) {
  structure <- GenomicRanges::GRanges(seqnames = chr, ranges = IRanges::IRanges(start = start, end = end), strand = strand)
  new("piRNAGene", ID = ID, symbol = symbol, name = name, description = description, structure = structure, product = product, piRNAID = piRNAID, piRNASequence = piRNASequence)
}

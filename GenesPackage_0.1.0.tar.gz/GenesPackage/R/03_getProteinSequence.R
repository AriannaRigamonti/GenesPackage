#' Get the protein sequence
#'
#' This function retrieves the sequence of a protein-coding gene.
#'
#' @param object A ProteinCodingGene object.
#' @return The protein sequence.
#' @export
#' @aliases getProteinSequence getProteinSequence,ProteinCodingGene-method
#' @examples
#' protein_gene <- createProteinCodingGene(
#'   1L, "SYMBOL", "Gene Name",
#'   "Description", "chr1", 1, 1000, "+",
#'   list(), "protein1", "SEQUENCE"
#' )
#' getProteinSequence(protein_gene)
setGeneric("getProteinSequence", function(object) standardGeneric("getProteinSequence"))

#' @rdname getProteinSequence
#' @export
setMethod("getProteinSequence", "ProteinCodingGene", function(object) object@proteinSequence)

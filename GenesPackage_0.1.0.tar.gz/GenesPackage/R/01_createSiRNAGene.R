#' Create a siRNAGene object
#' @param ID integer The gene ID.
#' @param symbol character. The gene symbol.
#' @param name character. The gene name.
#' @param description character. The gene description.
#' @param chr character. The chromosome location.
#' @param start numeric. The start position of the gene.
#' @param end numeric. The end position of the gene.
#' @param strand character. The strand of the gene.
#' @param product list. The gene product.
#' @param siRNAID character. The siRNA ID.
#' @param siRNASequence character. The siRNA sequence.
#' @return A siRNAGene object.
#' @export
#' @examples
#' sirna_gene <- createSiRNAGene(
#'   4L, "SYMBOL_SI", "siRNA Name", "siRNA Description",
#'   "chr1", 1, 1000, "+", list(), "sirna1", "SIRNA_SEQ"
#' )
#' sirna_gene
createSiRNAGene <- function(ID, symbol, name, description, chr, start, end, strand,
                            product, siRNAID, siRNASequence) {
  structure <- GenomicRanges::GRanges(
    seqnames = chr,
    ranges = IRanges::IRanges(start = start, end = end),
    strand = strand
  )
  new("siRNAGene",
    ID = ID, symbol = symbol, name = name, description = description,
    structure = structure, product = product, siRNAID = siRNAID, siRNASequence = siRNASequence
  )
}

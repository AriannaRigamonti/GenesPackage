#' Set the protein ID
#'
#' This method sets the protein ID of a ProteinCodingGene object.
#'
#' @param object A ProteinCodingGene object.
#' @param value The new protein ID.
#' @return The updated ProteinCodingGene object.
#' @title Set the protein ID
#' @name setProteinID
#' @aliases setProteinID<- setProteinID<-,ProteinCodingGene-method
#' @rdname setProteinID
#' @export
#' @examples
#' protein_gene <- createProteinCodingGene(
#'   1L, "SYMBOL", "Gene Name",
#'   "Description", "chr1", 1, 1000,
#'   "+", list(), "protein1", "SEQUENCE"
#' )
#' setProteinID(protein_gene) <- "new_protein1"
#' getProteinID(protein_gene)
setGeneric("setProteinID<-", function(object, value) standardGeneric("setProteinID<-"))

#' @rdname setProteinID
#' @export
setMethod("setProteinID<-", "ProteinCodingGene", function(object, value) {
  object@proteinID <- value
  object
})

#' Compute the length of the gene
#'
#' This function calculates the length of a gene based on its genomic structure.
#' The length is computed as the sum of the widths of the ranges in the gene's structure.
#'
#' @param object A Gene object.
#' @return The length of the gene as an integer.
#' @export
#' @aliases computeGeneLength computeGeneLength,Gene-method
#' @examples
#' gene <- createGene(
#'   ID = 1L, symbol = "SYMBOL", name = "Gene Name",
#'   description = "Description", chr = "chr1", start = 1,
#'   end = 1000, strand = "+", product = list()
#' )
#' computeGeneLength(gene)
setGeneric("computeGeneLength", function(object) {
  standardGeneric("computeGeneLength")
})

#' @rdname computeGeneLength
#' @export
setMethod("computeGeneLength", "Gene", function(object) {
  # Calculate the width (length) of the genomic ranges in the gene's structure
  sum(GenomicRanges::width(object@structure))
})

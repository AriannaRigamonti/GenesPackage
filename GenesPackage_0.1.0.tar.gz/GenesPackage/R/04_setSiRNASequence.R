#' Set the siRNA sequence
#' @name setSiRNASequence<-
#' @title Set the siRNA sequence
#' @param object A siRNAGene object.
#' @param value The new siRNA sequence.
#' @return The updated siRNAGene object.
#' @export
#' @aliases setSiRNASequence setSiRNASequence<-,siRNAGene-method
#' @examples
#' sirna_gene <- createSiRNAGene(
#'   4L, "SYMBOL_SI", "siRNA Name",
#'   "siRNA Description", "chr1", 1, 1000, "+",
#'   list(), "sirna1", "SIRNA_SEQ"
#' )
#' setSiRNASequence(sirna_gene) <- "NEW_SIRNA_SEQ"
#' getSiRNASequence(sirna_gene)
setGeneric("setSiRNASequence<-", function(object, value) standardGeneric("setSiRNASequence<-"))
setMethod("setSiRNASequence<-", "siRNAGene", function(object, value) {
  object@siRNASequence <- value
  object
})

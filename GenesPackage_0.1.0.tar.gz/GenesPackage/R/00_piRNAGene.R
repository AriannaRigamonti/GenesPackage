#' piRNAGene class
#'
#' A class representing a piRNA gene.
#'
#' @slot piRNAID character. The piRNA ID.
#' @slot piRNASequence character. The piRNA sequence.
#' @exportClass piRNAGene
#' @importFrom GenomicRanges GRanges seqnames start end strand
#' @importFrom IRanges IRanges
#' @importFrom methods new
#' @examples
#' gr <- GenomicRanges::GRanges(
#'   seqnames = "chr1",
#'   ranges = IRanges::IRanges(start = 1, end = 1000)
#' )
#' pirna_gene <- new("piRNAGene",
#'   ID = 8L, symbol = "SYMBOL_PI",
#'   name = "piRNA Name", description = "piRNA Description",
#'   structure = gr, product = list(), piRNAID = "pirna1",
#'   piRNASequence = "PIRNA_SEQ"
#' )
setClass("piRNAGene",
  contains = "Gene",
  slots = list(
    piRNAID = "character",
    piRNASequence = "character"
  )
)

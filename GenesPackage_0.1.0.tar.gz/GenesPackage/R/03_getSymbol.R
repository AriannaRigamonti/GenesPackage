#' Get the gene symbol
#'
#' This function retrieves the symbol of a gene.
#'
#' @param object A Gene object.
#' @return The gene symbol.
#' @export
#' @aliases getSymbol getSymbol,Gene-method
#' @examples
#' gene <- createGene(1L, "SYMBOL", "Gene Name", "Description", "chr1", 1, 1000, "+", list())
#' getSymbol(gene)
setGeneric("getSymbol", function(object) standardGeneric("getSymbol"))

#' @rdname getSymbol
#' @export
setMethod("getSymbol", "Gene", function(object) object@symbol)

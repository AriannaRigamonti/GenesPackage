#' Get the protein ID
#'
#' This function retrieves the ID of a protein-coding gene.
#'
#' @param object A ProteinCodingGene object.
#' @return The protein ID.
#' @export
#' @aliases getProteinID getProteinID,ProteinCodingGene-method
#' @examples
#' protein_gene <- createProteinCodingGene(
#'   1L, "SYMBOL", "Gene Name",
#'   "Description", "chr1", 1, 1000, "+",
#'   list(), "protein1", "SEQUENCE"
#' )
#' getProteinID(protein_gene)
setGeneric("getProteinID", function(object) standardGeneric("getProteinID"))

#' @rdname getProteinID
#' @export
setMethod("getProteinID", "ProteinCodingGene", function(object) object@proteinID)

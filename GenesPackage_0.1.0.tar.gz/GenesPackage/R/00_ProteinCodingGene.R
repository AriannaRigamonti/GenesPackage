#' ProteinCodingGene class
#'
#' A class representing a protein-coding gene.
#'
#' @slot proteinID character. The protein ID.
#' @slot proteinSequence character. The protein sequence.
#' @exportClass ProteinCodingGene
#' @importFrom GenomicRanges GRanges seqnames start end strand
#' @importFrom IRanges IRanges
#' @importFrom methods new
#' @examples
#' library(GenomicRanges)
#' gr <- GRanges(seqnames = "chr1", ranges = IRanges(start = 1, end = 1000))
#' protein_gene <- new("ProteinCodingGene",
#'   ID = 1L, symbol = "SYMBOL",
#'   name = "Gene Name", description = "Description",
#'   structure = gr, product = list(),
#'   proteinID = "protein1", proteinSequence = "SEQUENCE"
#' )
setClass("ProteinCodingGene",
  contains = "Gene",
  slots = list(
    proteinID = "character",
    proteinSequence = "character"
  )
)

#' Set the tRNA sequence
#' @name setTRNASequence<-
#' @title Set the tRNA sequence
#' @param object A tRNAGene object.
#' @param value The new tRNA sequence.
#' @return The updated tRNAGene object.
#' @export
#' @aliases setTRNASequence setTRNASequence<-,tRNAGene-method
#' @examples
#' trna_gene <- createTRNAGene(
#'   6L, "SYMBOL_T", "tRNA Name",
#'   "tRNA Description", "chr1", 1, 1000, "+",
#'   list(), "trna1", "TRNA_SEQ"
#' )
#' setTRNASequence(trna_gene) <- "NEW_TRNA_SEQ"
#' getTRNASequence(trna_gene)
setGeneric("setTRNASequence<-", function(object, value) standardGeneric("setTRNASequence<-"))
setMethod("setTRNASequence<-", "tRNAGene", function(object, value) {
  object@tRNASequence <- value
  object
})

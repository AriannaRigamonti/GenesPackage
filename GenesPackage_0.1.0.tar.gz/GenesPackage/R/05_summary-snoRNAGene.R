#' Summary method for snoRNAGene objects
#'
#' Provides a summary of the snoRNA gene information.
#'
#' @param object A snoRNAGene object.
#' @return A summary of the snoRNA gene information.
#' @name summary-snoRNAGene
#' @title Summary Method for snoRNAGene Class
#' @aliases summary-snoRNAGene summary,snoRNAGene-method
#' @rdname summary-snoRNAGene
#' @export
#' @importFrom methods callNextMethod
#' @examples
#' snorna_gene <- createSnoRNAGene(
#'   5L, "SYMBOL_SNO", "snoRNA Name",
#'   "snoRNA Description", "chr1", 1, 1000,
#'   "+", list(), "snorna1", "SNORNA_SEQ"
#' )
#' summary(snorna_gene)
setMethod("summary", "snoRNAGene", function(object) {
  callNextMethod()
  cat("snoRNA ID:", getSnoRNAID(object), "\n")
  cat("snoRNA Sequence:", getSnoRNASequence(object), "\n")
})

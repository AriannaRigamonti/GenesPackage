#' Set the rRNA sequence
#' @name setRRNASequence<-
#' @title Set the rRNA sequence
#' @param object A rRNAGene object.
#' @param value The new rRNA sequence.
#' @return The updated rRNAGene object.
#' @export
#' @aliases setRRNASequence setRRNASequence<-,rRNAGene-method
#' @examples
#' rrna_gene <- createRRNAGene(
#'   7L, "SYMBOL_R", "rRNA Name",
#'   "rRNA Description", "chr1", 1, 1000, "+",
#'   list(), "rrna1", "RRNA_SEQ"
#' )
#' setRRNASequence(rrna_gene) <- "NEW_RRNA_SEQ"
#' getRRNASequence(rrna_gene)
setGeneric("setRRNASequence<-", function(object, value) standardGeneric("setRRNASequence<-"))
setMethod("setRRNASequence<-", "rRNAGene", function(object, value) {
  object@rRNASequence <- value
  object
})

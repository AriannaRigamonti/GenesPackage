#' Get the microRNA sequence
#'
#' This function retrieves the sequence of a microRNA gene.
#'
#' @param object A microRNAGene object.
#' @return The microRNA sequence.
#' @export
#' @aliases getMicroRNASequence getMicroRNASequence,microRNAGene-method
#' @examples
#' mirna_gene <- createMicroRNAGene(
#'   3L, "SYMBOL_MIR", "MicroRNA Name",
#'   "MicroRNA Description", "chr1", 1, 1000,
#'   "+", list(), "mirna1", "SEED_SEQ"
#' )
#' getMicroRNASequence(mirna_gene)
setGeneric("getMicroRNASequence", function(object) standardGeneric("getMicroRNASequence"))

#' @rdname getMicroRNASequence
#' @export
setMethod("getMicroRNASequence", "microRNAGene", function(object) object@microRNASequence)

#' Get the microRNA ID
#'
#' This function retrieves the ID of a microRNA gene.
#'
#' @param object A microRNAGene object.
#' @return The microRNA ID.
#' @export
#' @aliases getMicroRNAID getMicroRNAID,microRNAGene-method
#' @examples
#' mirna_gene <- createMicroRNAGene(
#'   3L, "SYMBOL_MIR", "MicroRNA Name",
#'   "MicroRNA Description", "chr1", 1, 1000,
#'   "+", list(), "mirna1", "SEED_SEQ"
#' )
#' getMicroRNAID(mirna_gene)
setGeneric("getMicroRNAID", function(object) standardGeneric("getMicroRNAID"))

#' @rdname getMicroRNAID
#' @export
setMethod("getMicroRNAID", "microRNAGene", function(object) object@microRNAID)

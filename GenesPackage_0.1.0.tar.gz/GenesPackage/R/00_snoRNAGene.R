#' snoRNAGene class
#'
#' A class representing a snoRNA gene.
#'
#' @slot snoRNAID character. The snoRNA ID.
#' @slot snoRNASequence character. The snoRNA sequence.
#' @exportClass snoRNAGene
#' @importFrom GenomicRanges GRanges seqnames start end strand
#' @importFrom IRanges IRanges
#' @importFrom methods new
#' @examples
#' gr <- GenomicRanges::GRanges(
#'   seqnames = "chr1",
#'   ranges = IRanges::IRanges(start = 1, end = 1000)
#' )
#' snorna_gene <- new("snoRNAGene",
#'   ID = 5L, symbol = "SYMBOL_SNO",
#'   name = "snoRNA Name", description = "snoRNA Description",
#'   structure = gr, product = list(),
#'   snoRNAID = "snorna1", snoRNASequence = "SNO_SEQ"
#' )
setClass("snoRNAGene",
  contains = "Gene",
  slots = list(
    snoRNAID = "character",
    snoRNASequence = "character"
  )
)

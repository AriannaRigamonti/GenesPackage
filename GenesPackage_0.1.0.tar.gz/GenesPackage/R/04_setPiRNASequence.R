#' Set the piRNA sequence
#'
#' This method sets the piRNA sequence of a piRNAGene object.
#'
#' @param object A piRNAGene object.
#' @param value The new piRNA sequence.
#' @return The updated piRNAGene object.
#' @title Set the piRNA sequence
#' @name setPiRNASequence
#' @aliases setPiRNASequence<- setPiRNASequence<-,piRNAGene-method
#' @rdname setPiRNASequence
#' @export
#' @examples
#' pirna_gene <- createPiRNAGene(
#'   8L, "SYMBOL_PI", "piRNA Name",
#'   "piRNA Description", "chr1", 1, 1000,
#'   "+", list(), "pirna1", "PIRNA_SEQ"
#' )
#' setPiRNASequence(pirna_gene) <- "NEW_PIRNA_SEQ"
#' getPiRNASequence(pirna_gene)
setGeneric("setPiRNASequence<-", function(object, value) {
  standardGeneric("setPiRNASequence<-")
})

#' @rdname setPiRNASequence
#' @export
setMethod("setPiRNASequence<-", "piRNAGene", function(object, value) {
  object@piRNASequence <- value
  object
})

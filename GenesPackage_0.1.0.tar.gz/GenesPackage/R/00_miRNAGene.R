#' microRNAGene class
#'
#' A class representing a microRNA gene.
#'
#' @slot microRNAID character. The microRNA ID.
#' @slot microRNASequence character. The microRNA sequence.
#' @exportClass microRNAGene
#' @importFrom GenomicRanges GRanges seqnames start end strand
#' @importFrom IRanges IRanges
#' @importFrom methods new
#' @examples
#' gr <- GenomicRanges::GRanges(
#'   seqnames = "chr1",
#'   ranges = IRanges::IRanges(start = 1, end = 1000)
#' )
#' mirna_gene <- new("microRNAGene",
#'   ID = 3L, symbol = "SYMBOL_MIR",
#'   name = "MicroRNA Name", description = "MicroRNA Description",
#'   structure = gr, product = list(), microRNAID = "mirna1",
#'   microRNASequence = "SEED_SEQ"
#' )
setClass("microRNAGene",
  contains = "Gene",
  slots = list(
    microRNAID = "character",
    microRNASequence = "character"
  )
)

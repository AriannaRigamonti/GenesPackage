#' Summary method for tRNAGene objects
#'
#' Provides a summary of the tRNA gene information.
#'
#' @param object A tRNAGene object.
#' @return A summary of the tRNA gene information.
#' @name summary-tRNAGene
#' @title Summary Method for tRNAGene Class
#' @aliases summary-tRNAGene summary,tRNAGene-method
#' @rdname summary-tRNAGene
#' @export
#' @importFrom methods callNextMethod
#' @examples
#' trna_gene <- createTRNAGene(
#'   6L, "SYMBOL_T", "tRNA Name",
#'   "tRNA Description", "chr1", 1, 1000,
#'   "+", list(), "trna1", "TRNA_SEQ"
#' )
#' summary(trna_gene)
setMethod("summary", "tRNAGene", function(object) {
  callNextMethod()
  cat("tRNA ID:", getTRNAID(object), "\n")
  cat("tRNA Sequence:", getTRNASequence(object), "\n")
})

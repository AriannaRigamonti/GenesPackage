#' Create an rRNAGene object
#'
#' @param ID integer The gene ID (e.g., Ensembl ID or NCBI gene ID).
#' @param symbol character. The gene symbol.
#' @param name character. The gene name.
#' @param description character. The gene description.
#' @param chr character. The chromosome location.
#' @param start numeric. The start position of the gene.
#' @param end numeric. The end position of the gene.
#' @param strand character. The strand of the gene.
#' @param product list. The gene product.
#' @param rRNAID character. The rRNA ID.
#' @param rRNASequence character. The rRNA sequence.
#' @return An rRNAGene object.
#' @export
#' @examples
#' rrna_gene <- createRRNAGene(
#'   7L, "SYMBOL_R", "rRNA Name", "rRNA Description",
#'   "chr1", 1, 1000, "+", list(), "rrna1", "RRNA_SEQ"
#' )
#' rrna_gene
createRRNAGene <- function(ID, symbol, name, description, chr, start, end, strand,
                           product, rRNAID, rRNASequence) {
  structure <- GenomicRanges::GRanges(
    seqnames = chr,
    ranges = IRanges::IRanges(start = start, end = end),
    strand = strand
  )
  new("rRNAGene",
    ID = ID, symbol = symbol, name = name, description = description,
    structure = structure, product = product, rRNAID = rRNAID, rRNASequence = rRNASequence
  )
}

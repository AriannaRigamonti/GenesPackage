#' Set the rRNA ID
#' @name setRRNAID<-
#' @title Set the rRNA ID
#' @param object A rRNAGene object.
#' @param value The new rRNA ID.
#' @return The updated rRNAGene object.
#' @export
#' @aliases setRRNAID setRRNAID<-,rRNAGene-method
#' @examples
#' rrna_gene <- createRRNAGene(
#'   7L, "SYMBOL_R", "rRNA Name",
#'   "rRNA Description", "chr1", 1, 1000, "+",
#'   list(), "rrna1", "RRNA_SEQ"
#' )
#' setRRNAID(rrna_gene) <- "new_rrna1"
#' getRRNAID(rrna_gene)
setGeneric("setRRNAID<-", function(object, value) standardGeneric("setRRNAID<-"))
setMethod("setRRNAID<-", "rRNAGene", function(object, value) {
  object@rRNAID <- value
  object
})

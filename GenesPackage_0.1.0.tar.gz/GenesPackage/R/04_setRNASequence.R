#' Set the RNA sequence
#'
#' This method sets the RNA sequence of a lncRNAGene object.
#'
#' @param object A lncRNAGene object.
#' @param value The new RNA sequence.
#' @return The updated lncRNAGene object.
#' @title Set the RNA sequence
#' @name setRNASequence
#' @aliases setRNASequence<- setRNASequence<-,lncRNAGene-method
#' @rdname setRNASequence
#' @export
#' @examples
#' lncrna_gene <- createLncRNAGene(
#'   2L, "SYMBOL_LNC", "LncRNA Name",
#'   "LncRNA Description", "chr1", 1, 1000,
#'   "+", list(), "lncrna1", "RNA_SEQUENCE"
#' )
#' setRNASequence(lncrna_gene) <- "NEW_RNA_SEQUENCE"
#' getRNASequence(lncrna_gene)
setGeneric("setRNASequence<-", function(object, value) {
  standardGeneric("setRNASequence<-")
})

#' @rdname setRNASequence
#' @export
setMethod("setRNASequence<-", "lncRNAGene", function(object, value) {
  object@RNASequence <- value
  object
})

#' Get the snoRNA ID
#'
#' This function retrieves the ID of a snoRNA gene.
#'
#' @param object A snoRNAGene object.
#' @return The snoRNA ID.
#' @export
#' @aliases getSnoRNAID getSnoRNAID,snoRNAGene-method
#' @examples
#' snorna_gene <- createSnoRNAGene(
#'   5L, "SYMBOL_SNO", "snoRNA Name",
#'   "snoRNA Description", "chr1", 1, 1000, "+",
#'   list(), "snorna1", "SNORNA_SEQ"
#' )
#' getSnoRNAID(snorna_gene)
setGeneric("getSnoRNAID", function(object) standardGeneric("getSnoRNAID"))

#' @rdname getSnoRNAID
#' @export
setMethod("getSnoRNAID", "snoRNAGene", function(object) object@snoRNAID)

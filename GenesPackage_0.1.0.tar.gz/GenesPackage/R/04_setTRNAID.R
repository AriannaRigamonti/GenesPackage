#' Set the tRNA ID
#' @name setTRNAID<-
#' @title Set the tRNA ID
#' @param object A tRNAGene object.
#' @param value The new tRNA ID.
#' @return The updated tRNAGene object.
#' @export
#' @aliases setTRNAID setTRNAID<-,tRNAGene-method
#' @examples
#' trna_gene <- createTRNAGene(
#'   6L, "SYMBOL_T", "tRNA Name", "tRNA
#'                             Description", "chr1", 1, 1000, "+", list(),
#'   "trna1", "TRNA_SEQ"
#' )
#' setTRNAID(trna_gene) <- "new_trna1"
#' getTRNAID(trna_gene)
setGeneric("setTRNAID<-", function(object, value) standardGeneric("setTRNAID<-"))
setMethod("setTRNAID<-", "tRNAGene", function(object, value) {
  object@tRNAID <- value
  object
})

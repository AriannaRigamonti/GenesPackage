#' Get the tRNA sequence
#'
#' This function retrieves the sequence of a tRNA gene.
#'
#' @param object A tRNAGene object.
#' @return The tRNA sequence.
#' @export
#' @aliases getTRNASequence getTRNASequence,tRNAGene-method
#' @examples
#' trna_gene <- createTRNAGene(
#'   6L, "SYMBOL_T", "tRNA Name",
#'   "tRNA Description", "chr1", 1, 1000, "+",
#'   list(), "trna1", "TRNA_SEQ"
#' )
#' getTRNASequence(trna_gene)
setGeneric("getTRNASequence", function(object) standardGeneric("getTRNASequence"))

#' @rdname getTRNASequence
#' @export
setMethod("getTRNASequence", "tRNAGene", function(object) object@tRNASequence)

#' Set the gene structure
#' @name setStructure<-
#' @title Set the gene structure
#' @param object A Gene object.
#' @param value The new gene structure.
#' @return The updated Gene object.
#' @export
#' @aliases setStructure setStructure<-,Gene-method
#' @examples
#' gene <- createGene(
#'   1L, "SYMBOL", "Gene Name", "Description", "chr1",
#'   1, 1000, "+", list()
#' )
#' new_structure <- GenomicRanges::GRanges(
#'   seqnames = "chr2",
#'   ranges = IRanges::IRanges(
#'     start =
#'       100, end = 2000
#'   ), strand = "-"
#' )
#' setStructure(gene) <- new_structure
#' getStructure(gene)
setGeneric("setStructure<-", function(object, value) standardGeneric("setStructure<-"))
setMethod("setStructure<-", "Gene", function(object, value) {
  object@structure <- value
  object
})

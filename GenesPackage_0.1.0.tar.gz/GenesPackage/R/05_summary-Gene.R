#' Summary of a Gene object
#'
#' This function provides a summary of a Gene object.
#'
#' @param object A Gene object.
#' @param ... Additional arguments (currently not used).
#' @return A summary of the Gene object.
#' @title Summary of a Gene object
#' @name summary-Gene
#' @aliases summary summary,Gene-method
#' @rdname summary-Gene
#' @export
#' @importFrom methods callNextMethod
#' @examples
#' gene <- createGene(1L, "SYMBOL", "Gene Name", "Description", "chr1", 1, 1000,
#'                    "+", list())
#' summary(gene)
setGeneric("summary", function(object) standardGeneric("summary"))

setMethod("summary", "Gene", function(object) {
  gene_length <- computeGeneLength(object)
  cat("Gene ID:", getID(object), "\n")
  cat("Gene Symbol:", getSymbol(object), "\n")
  cat("Gene Name:", getName(object), "\n")
  cat("Gene Description:", getDescription(object), "\n")
  cat("Chromosome:", as.character(seqnames(getStructure(object))), "\n")
  cat("Start Position:", start(getStructure(object)), "\n")
  cat("End Position:", end(getStructure(object)), "\n")
  cat("Strand:", as.character(strand(getStructure(object))), "\n")
  cat("Gene Length:", gene_length, "\n")
  cat("Product:\n")
  print(getProduct(object))
})

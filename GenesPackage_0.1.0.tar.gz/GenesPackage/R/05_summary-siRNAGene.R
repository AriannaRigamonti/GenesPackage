#' Summary method for siRNAGene objects
#'
#' Provides a summary of the siRNA gene information.
#'
#' @param object A siRNAGene object.
#' @return A summary of the siRNA gene information.
#' @name summary-siRNAGene
#' @title Summary Method for siRNAGene Class
#' @aliases summary-siRNAGene summary,siRNAGene-method
#' @rdname summary-siRNAGene
#' @export
#' @importFrom methods callNextMethod
#' @examples
#' sirna_gene <- createSiRNAGene(
#'   4L, "SYMBOL_SI", "siRNA Name",
#'   "siRNA Description", "chr1", 1, 1000,
#'   "+", list(), "sirna1", "SIRNA_SEQ"
#' )
#' summary(sirna_gene)
setMethod("summary", "siRNAGene", function(object) {
  callNextMethod()
  cat("siRNA ID:", getSiRNAID(object), "\n")
  cat("siRNA Sequence:", getSiRNASequence(object), "\n")
})

#' Set the lncRNA ID
#'
#' This method sets the lncRNA ID of a lncRNAGene object.
#'
#' @param object A lncRNAGene object.
#' @param value The new lncRNA ID.
#' @return The updated lncRNAGene object.
#' @title Set the lncRNA ID
#' @name setLncRNAID
#' @aliases setLncRNAID<- setLncRNAID<-,lncRNAGene-method
#' @rdname setLncRNAID
#' @export
#' @examples
#' lncrna_gene <- createLncRNAGene(
#'   2L, "SYMBOL_LNC", "LncRNA Name",
#'   "LncRNA Description", "chr1", 1, 1000, "+",
#'   list(), "lncrna1", "RNA_SEQUENCE"
#' )
#' setLncRNAID(lncrna_gene) <- "new_lncrna1"
#' getLncRNAID(lncrna_gene)
setGeneric("setLncRNAID<-", function(object, value) standardGeneric("setLncRNAID<-"))

#' @rdname setLncRNAID
#' @export
setMethod("setLncRNAID<-", "lncRNAGene", function(object, value) {
  object@lncRNAID <- value
  object
})

#' Get the RNA sequence
#'
#' This function retrieves the RNA sequence of a lncRNA gene.
#'
#' @param object A lncRNAGene object.
#' @return The RNA sequence.
#' @export
#' @aliases getRNASequence getRNASequence,lncRNAGene-method
#' @examples
#' lncrna_gene <- createLncRNAGene(
#'   2L, "SYMBOL_LNC", "LncRNA Name",
#'   "LncRNA Description", "chr1", 1, 1000, "+",
#'   list(), "lncrna1", "RNA_SEQUENCE"
#' )
#' getRNASequence(lncrna_gene)
setGeneric("getRNASequence", function(object) standardGeneric("getRNASequence"))

#' @rdname getRNASequence
#' @export
setMethod("getRNASequence", "lncRNAGene", function(object) object@RNASequence)

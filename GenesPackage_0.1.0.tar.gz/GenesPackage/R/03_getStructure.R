#' Get the gene structure
#'
#' This function retrieves the structure of a gene.
#'
#' @param object A Gene object.
#' @return The gene structure (a GRanges object).
#' @export
#' @aliases getStructure getStructure,Gene-method
#' @examples
#' gene <- createGene(1L, "SYMBOL", "Gene Name", "Description", "chr1", 1, 1000, "+", list())
#' getStructure(gene)
setGeneric("getStructure", function(object) standardGeneric("getStructure"))

#' @rdname getStructure
#' @export
setMethod("getStructure", "Gene", function(object) object@structure)

#' Summary method for rRNAGene objects
#'
#' Provides a summary of the rRNA gene information.
#'
#' @param object A rRNAGene object.
#' @return A summary of the rRNA gene information.
#' @name summary-rRNAGene
#' @title Summary Method for rRNAGene Class
#' @aliases summary-rRNAGene summary,rRNAGene-method
#' @rdname summary-rRNAGene
#' @export
#' @importFrom methods callNextMethod
#' @examples
#' rrna_gene <- createRRNAGene(
#'   7L, "SYMBOL_R", "rRNA Name",
#'   "rRNA Description", "chr1", 1, 1000,
#'   "+", list(), "rrna1", "RRNA_SEQ"
#' )
#' summary(rrna_gene)
setMethod("summary", "rRNAGene", function(object) {
  callNextMethod()
  cat("rRNA ID:", getRRNAID(object), "\n")
  cat("rRNA Sequence:", getRRNASequence(object), "\n")
})

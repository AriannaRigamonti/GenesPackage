#' Create a snoRNAGene object
#' @param ID integer The gene ID.
#' @param symbol character. The gene symbol.
#' @param name character. The gene name.
#' @param description character. The gene description.
#' @param chr character. The chromosome location.
#' @param start numeric. The start position of the gene.
#' @param end numeric. The end position of the gene.
#' @param strand character. The strand of the gene.
#' @param product list. The gene product.
#' @param snoRNAID character. The snoRNA ID.
#' @param snoRNASequence character. The snoRNA sequence.
#' @return A snoRNAGene object.
#' @export
#' @examples
#' snorna_gene <- createSnoRNAGene(
#'   5L, "SYMBOL_SNO", "snoRNA Name",
#'   "snoRNA Description", "chr1", 1, 1000, "+",
#'   list(), "snorna1", "SNORNA_SEQ"
#' )
#' snorna_gene
createSnoRNAGene <- function(ID, symbol, name, description, chr, start, end, strand,
                             product, snoRNAID, snoRNASequence) {
  structure <- GenomicRanges::GRanges(
    seqnames = chr,
    ranges = IRanges::IRanges(start = start, end = end),
    strand = strand
  )
  new("snoRNAGene",
    ID = ID, symbol = symbol, name = name, description = description,
    structure = structure, product = product, snoRNAID = snoRNAID, snoRNASequence = snoRNASequence
  )
}
